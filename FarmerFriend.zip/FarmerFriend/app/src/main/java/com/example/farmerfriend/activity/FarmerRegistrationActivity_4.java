package com.example.farmerfriend.activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.farmerfriend.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.example.farmerfriend.module.Farmer;

public class FarmerRegistrationActivity_4 extends AppCompatActivity {

    private EditText farmerNameEditText, farmerPhone, farmerEmail, farmerAddress;
    private Button registerButton;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farmer_registration_4);

        // Initialize views
        farmerNameEditText = findViewById(R.id.farmerNameEditText);
        farmerPhone = findViewById(R.id.farmerPhone);
        farmerEmail = findViewById(R.id.farmerEmail);
        farmerAddress = findViewById(R.id.farmerAddress);
        registerButton = findViewById(R.id.registerButton);

        // Initialize Firebase Database reference
        databaseReference = FirebaseDatabase.getInstance().getReference("farmers");

        // Set up the register button click listener
        registerButton.setOnClickListener(view -> registerFarmer());
    }

    private void registerFarmer() {
        String name = farmerNameEditText.getText().toString().trim();
        String phone = farmerPhone.getText().toString().trim();
        String email = farmerEmail.getText().toString().trim();
        String address = farmerAddress.getText().toString().trim();

        // Validate input
        if (name.isEmpty() || phone.isEmpty() || email.isEmpty() || address.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        if (phone.length() != 10) {
            Toast.makeText(this, "Phone number must be exactly 10 digits", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "Please enter a valid email address", Toast.LENGTH_SHORT).show();
            return;
        }

        // Create a Farmer object with the validated input
        Farmer farmer = new Farmer(name, phone, email, address);

        // Save the farmer data to Firebase Realtime Database
        databaseReference.push().setValue(farmer).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(FarmerRegistrationActivity_4.this, "Farmer registered successfully!", Toast.LENGTH_SHORT).show();
                // Redirect to FarmerIntroductionActivity
                Intent intent = new Intent(FarmerRegistrationActivity_4.this, FarmerIntroductionActivity_4_1.class);
                startActivity(intent);
                finish();
            } else {
                Toast.makeText(FarmerRegistrationActivity_4.this, "Failed to register farmer. Please try again.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
