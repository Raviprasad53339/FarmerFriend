package com.example.farmerfriend.activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import com.example.farmerfriend.R;

public class ThankYouFarmerActivity_8 extends AppCompatActivity {

    private TextView thankYouTextView;
    private TextView paymentSuccessTextView;
    private TextView etaTextView;
    private Button nextButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_thank_you_farmer_8);

        thankYouTextView = findViewById(R.id.thankYouTextView);
        paymentSuccessTextView = findViewById(R.id.paymentSuccessTextView);
        etaTextView = findViewById(R.id.etaTextView);
        nextButton = findViewById(R.id.nextButton);

        String pageType = getIntent().getStringExtra("page_type");

        if ("thank_you".equals(pageType)) {
            thankYouTextView.setText("Thank You");
            paymentSuccessTextView.setText("PAYMENT SUCCESSFUL");
            etaTextView.setText("Estimated Delivery: 3 Days");
        } else if ("contact_farmer".equals(pageType)) {
            thankYouTextView.setText("Thank You");
            paymentSuccessTextView.setText("PLEASE CONTACT YOUR FARMER AS SOON AS POSSIBLE");
            etaTextView.setText("Estimated Delivery: Not Applicable");
        }

        nextButton.setOnClickListener(v -> {
            // Navigate back to the main interface or relevant page
            Intent intent = new Intent(ThankYouFarmerActivity_8.this, FarmerMainActivity_5.class);
            startActivity(intent);
        });
    }
}
