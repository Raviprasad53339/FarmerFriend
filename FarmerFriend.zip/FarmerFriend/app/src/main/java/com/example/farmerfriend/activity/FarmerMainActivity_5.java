package com.example.farmerfriend.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.farmerfriend.R;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class FarmerMainActivity_5 extends AppCompatActivity {

    private Spinner spinnerEquipment;
    private EditText etCustomEquipment, etOffer;
    private Button btnFindRenter;
    private DatabaseReference rentersRef;
    private ArrayList<String> equipmentList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farmer_main_5);

        spinnerEquipment = findViewById(R.id.spinner_equipment);
        etCustomEquipment = findViewById(R.id.et_custom_equipment);
        etOffer = findViewById(R.id.et_offer);
        btnFindRenter = findViewById(R.id.btn_find_renter);
        rentersRef = FirebaseDatabase.getInstance().getReference("renters");
        equipmentList = new ArrayList<>();

        // Fetch equipment data from Firebase
        rentersRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                equipmentList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    String equipment = snapshot.child("equipment").getValue(String.class);
                    if (equipment != null) {
                        equipmentList.add(equipment);
                    }
                }
                equipmentList.add(0, "Other"); // Add "Other" option at the beginning of the list

                ArrayAdapter<String> adapter = new ArrayAdapter<>(FarmerMainActivity_5.this, android.R.layout.simple_spinner_item, equipmentList);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                spinnerEquipment.setAdapter(adapter);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(FarmerMainActivity_5.this, "Failed to load equipment data.", Toast.LENGTH_SHORT).show();
            }
        });

        // Show or hide custom equipment field based on selection
        spinnerEquipment.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selected = equipmentList.get(position);
                if (selected.equals("Other")) {
                    etCustomEquipment.setVisibility(View.VISIBLE);
                } else {
                    etCustomEquipment.setVisibility(View.GONE);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                etCustomEquipment.setVisibility(View.GONE);
            }
        });

        btnFindRenter.setOnClickListener(v -> {
            String selectedEquipment = spinnerEquipment.getSelectedItem().toString();
            if (selectedEquipment.equals("Other")) {
                selectedEquipment = etCustomEquipment.getText().toString();
            }
            String offer = etOffer.getText().toString();

            if (offer.isEmpty()) {
                Toast.makeText(FarmerMainActivity_5.this, "Please enter an offer.", Toast.LENGTH_SHORT).show();
            } else if (selectedEquipment.isEmpty()) {
                Toast.makeText(FarmerMainActivity_5.this, "Please enter the equipment name.", Toast.LENGTH_SHORT).show();
            } else {
                // Redirect to OfferActivity with selected equipment and offer
                Intent intent = new Intent(FarmerMainActivity_5.this, OfferActivity_6.class);
                intent.putExtra("selectedEquipment", selectedEquipment);
                intent.putExtra("offerAmount", Integer.parseInt(offer)); // Pass the offer amount as an integer
                startActivity(intent);
            }
        });
    }
}
