package com.example.farmerfriend.activity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.example.farmerfriend.R;
import com.example.farmerfriend.module.Renter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class OfferActivity_6 extends AppCompatActivity {

    private EditText offerAmountTextView;
    private Button decrementButton, incrementButton, applyNowButton, acceptButton1, acceptButton2, acceptButton3, acceptButton4, acceptButton5, acceptButton6, acceptButton7;
    private ConstraintLayout renterCard1, renterCard2, renterCard3, renterCard4, renterCard5, renterCard6, renterCard7;
    private ImageView renterImage1, renterImage2, renterImage3, renterImage4, renterImage5, renterImage6, renterImage7;
    private TextView renterName1, renterName2, renterName3, renterName4, renterName5, renterName6, renterName7;
    private TextView depositView1, depositView2, depositView3, depositView4, depositView5, depositView6, depositView7;
    private TextView rateView1, rateView2, rateView3, rateView4, rateView5, rateView6, rateView7;
    private TextView perDay1, perDay2, perDay3, perDay4, perDay5, perDay6, perDay7;
    private DatabaseReference rentersRef;
    private List<Renter> rentersList;
    private String selectedEquipment;
    private int offerAmount;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_offer_6);

        // Initialize views
        offerAmountTextView = findViewById(R.id.offerAmountTextView);
        decrementButton = findViewById(R.id.decrementButton);
        incrementButton = findViewById(R.id.incrementButton);
        applyNowButton = findViewById(R.id.applyNowButton);

        // Renter 1 views
        renterCard1 = findViewById(R.id.renterCard1);
        renterImage1 = findViewById(R.id.renterImage1);
        renterName1 = findViewById(R.id.renterName1);
        depositView1 = findViewById(R.id.depositView1);
        rateView1 = findViewById(R.id.rateView1);
        perDay1 = findViewById(R.id.perDay1);
        acceptButton1 = findViewById(R.id.acceptButton1);

        // Renter 2 views
        renterCard2 = findViewById(R.id.renterCard2);
        renterImage2 = findViewById(R.id.renterImage2);
        renterName2 = findViewById(R.id.renterName2);
        depositView2 = findViewById(R.id.depositView2);
        rateView2 = findViewById(R.id.rateView2);
        perDay2 = findViewById(R.id.perDay2);
        acceptButton2 = findViewById(R.id.acceptButton2);

        // Renter 3 views
        renterCard3 = findViewById(R.id.renterCard3);
        renterImage3 = findViewById(R.id.renterImage3);
        renterName3 = findViewById(R.id.renterName3);
        depositView3 = findViewById(R.id.depositView3);
        rateView3 = findViewById(R.id.rateView3);
        perDay3 = findViewById(R.id.perDay3);
        acceptButton3 = findViewById(R.id.acceptButton3);

        // Renter 4 views
        renterCard4 = findViewById(R.id.renterCard4);
        renterImage4 = findViewById(R.id.renterImage4);
        renterName4 = findViewById(R.id.renterName4);
        depositView4 = findViewById(R.id.depositView4);
        rateView4 = findViewById(R.id.rateView4);
        perDay4 = findViewById(R.id.perDay4);
        acceptButton4 = findViewById(R.id.acceptButton4);

        // Renter 5 views
        renterCard5 = findViewById(R.id.renterCard5);
        renterImage5 = findViewById(R.id.renterImage5);
        renterName5 = findViewById(R.id.renterName5);
        depositView5 = findViewById(R.id.depositView5);
        rateView5 = findViewById(R.id.rateView5);
        perDay5 = findViewById(R.id.perDay5);
        acceptButton5 = findViewById(R.id.acceptButton5);

        // Renter 6 views
        renterCard6 = findViewById(R.id.renterCard6);
        renterImage6 = findViewById(R.id.renterImage6);
        renterName6 = findViewById(R.id.renterName6);
        depositView6 = findViewById(R.id.depositView6);
        rateView6 = findViewById(R.id.rateView6);
        perDay6 = findViewById(R.id.perDay6);
        acceptButton6 = findViewById(R.id.acceptButton6);

        // Renter 7 views
        renterCard7 = findViewById(R.id.renterCard7);
        renterImage7 = findViewById(R.id.renterImage7);
        renterName7 = findViewById(R.id.renterName7);
        depositView7 = findViewById(R.id.depositView7);
        rateView7 = findViewById(R.id.rateView7);
        perDay7 = findViewById(R.id.perDay7);
        acceptButton7 = findViewById(R.id.acceptButton7);

        // Initialize Firebase database reference
        rentersRef = FirebaseDatabase.getInstance().getReference("renters");
        rentersList = new ArrayList<>();

        // Set default offer amount and ensure valid input
        offerAmountTextView.setText("0");
        offerAmountTextView.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (s.toString().isEmpty() || !s.toString().matches("-?\\d+")) {
                    offerAmountTextView.setText("0");
                }
            }
        });

        // Increment and decrement logic
        decrementButton.setOnClickListener(v -> adjustOfferAmount(-5));
        incrementButton.setOnClickListener(v -> adjustOfferAmount(5));

        // Get data from intent
        Intent intent = getIntent();
        selectedEquipment = intent.getStringExtra("selectedEquipment");
        offerAmount = intent.getIntExtra("offerAmount", 0);
        offerAmountTextView.setText(String.valueOf(offerAmount));

        // Load renters from Firebase
        loadRenters();

        // Apply button logic
        applyNowButton.setOnClickListener(v -> {
            Toast.makeText(OfferActivity_6.this, "Offer applied.", Toast.LENGTH_SHORT).show();
        });

        // Accept button logic for Renter 1 through 7
        acceptButton1.setOnClickListener(v -> acceptOffer(0));
        acceptButton2.setOnClickListener(v -> acceptOffer(1));
        acceptButton3.setOnClickListener(v -> acceptOffer(2));
        acceptButton4.setOnClickListener(v -> acceptOffer(3));
        acceptButton5.setOnClickListener(v -> acceptOffer(4));
        acceptButton6.setOnClickListener(v -> acceptOffer(5));
        acceptButton7.setOnClickListener(v -> acceptOffer(6));
    }

    private void adjustOfferAmount(int adjustment) {
        int currentAmount = Integer.parseInt(offerAmountTextView.getText().toString());
        currentAmount += adjustment;
        if (currentAmount < 0) currentAmount = 0; // Ensure non-negative values
        offerAmountTextView.setText(String.valueOf(currentAmount));
    }

    private void loadRenters() {
        rentersRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                rentersList.clear();
                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                    Renter renter = snapshot.getValue(Renter.class);
                    if (renter != null && renter.getEquipment().equalsIgnoreCase(selectedEquipment)) {
                        rentersList.add(renter);
                    }
                }
                displayRenters();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(OfferActivity_6.this, "Failed to load renters.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void displayRenters() {
        // Loop to display renters up to 7
        for (int i = 0; i < rentersList.size(); i++) {
            Renter renter = rentersList.get(i);
            switch (i) {
                case 0:
                    renterCard1.setVisibility(View.VISIBLE);
                    renterName1.setText(renter.getRenterName());
                    depositView1.setText(String.valueOf(renter.getDeposit()));
                    rateView1.setText(String.valueOf(renter.getRentPerDay()));
                    perDay1.setText(getString(R.string.per_day_label));
                    break;
                case 1:
                    renterCard2.setVisibility(View.VISIBLE);
                    renterName2.setText(renter.getRenterName());
                    depositView2.setText(String.valueOf(renter.getDeposit()));
                    rateView2.setText(String.valueOf(renter.getRentPerDay()));
                    perDay2.setText(getString(R.string.per_day_label));
                    break;
                case 2:
                    renterCard3.setVisibility(View.VISIBLE);
                    renterName3.setText(renter.getRenterName());
                    depositView3.setText(String.valueOf(renter.getDeposit()));
                    rateView3.setText(String.valueOf(renter.getRentPerDay()));
                    perDay3.setText(getString(R.string.per_day_label));
                    break;
                case 3:
                    renterCard4.setVisibility(View.VISIBLE);
                    renterName4.setText(renter.getRenterName());
                    depositView4.setText(String.valueOf(renter.getDeposit()));
                    rateView4.setText(String.valueOf(renter.getRentPerDay()));
                    perDay4.setText(getString(R.string.per_day_label));
                    break;
                case 4:
                    renterCard5.setVisibility(View.VISIBLE);
                    renterName5.setText(renter.getRenterName());
                    depositView5.setText(String.valueOf(renter.getDeposit()));
                    rateView5.setText(String.valueOf(renter.getRentPerDay()));
                    perDay5.setText(getString(R.string.per_day_label));
                    break;
                case 5:
                    renterCard6.setVisibility(View.VISIBLE);
                    renterName6.setText(renter.getRenterName());
                    depositView6.setText(String.valueOf(renter.getDeposit()));
                    rateView6.setText(String.valueOf(renter.getRentPerDay()));
                    perDay6.setText(getString(R.string.per_day_label));
                    break;
                case 6:
                    renterCard7.setVisibility(View.VISIBLE);
                    renterName7.setText(renter.getRenterName());
                    depositView7.setText(String.valueOf(renter.getDeposit()));
                    rateView7.setText(String.valueOf(renter.getRentPerDay()));
                    perDay7.setText(getString(R.string.per_day_label));
                    break;
            }
        }
    }

    private void acceptOffer(int position) {
        if (position < rentersList.size()) {
            Renter selectedRenter = rentersList.get(position);
            Intent intent = new Intent(OfferActivity_6.this, RenterInfoActivity_7.class);
            intent.putExtra("renterId", selectedRenter.getRenterId());
            intent.putExtra("renterName", selectedRenter.getRenterName());
            intent.putExtra("renterDeposit", selectedRenter.getDeposit());
            intent.putExtra("renterRatePerDay", selectedRenter.getRentPerDay());
            intent.putExtra("renterEquipment", selectedRenter.getEquipment());
            startActivity(intent);
        }
    }
}
