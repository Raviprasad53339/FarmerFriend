package com.example.farmerfriend.module;

public class Renter {
    private String renterId;
    private String renterName;
    private String renterPhone;
    private String renterEmail;
    private String renterAddress;
    private String equipment;
    private String rentPerDay;
    private String deposit;

    public Renter() {
        // Default constructor required for calls to DataSnapshot.getValue(Renter.class)
    }

    public Renter(String renterId, String renterName, String renterPhone, String renterEmail, String renterAddress, String equipment, String rentPerDay, String deposit) {
        this.renterId = renterId;
        this.renterName = renterName;
        this.renterPhone = renterPhone;
        this.renterEmail = renterEmail;
        this.renterAddress = renterAddress;
        this.equipment = equipment;
        this.rentPerDay = rentPerDay;
        this.deposit = deposit;
    }

    public String getRenterId() {
        return renterId;
    }

    public String getRenterName() {
        return renterName;
    }

    public String getRenterPhone() {
        return renterPhone;
    }

    public String getRenterEmail() {
        return renterEmail;
    }

    public String getRenterAddress() {
        return renterAddress;
    }

    public String getEquipment() {
        return equipment;
    }

    public String getRentPerDay() {
        return rentPerDay;
    }

    public String getDeposit() {
        return deposit;
    }



}
