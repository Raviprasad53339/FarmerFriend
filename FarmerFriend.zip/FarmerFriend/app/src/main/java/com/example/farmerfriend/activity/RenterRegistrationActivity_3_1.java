package com.example.farmerfriend.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.farmerfriend.R;
import com.example.farmerfriend.module.Renter;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class RenterRegistrationActivity_3_1 extends AppCompatActivity {

    private EditText renterNameEditText, renterPhoneEditText, renterEmailEditText, renterAddressEditText;
    private EditText equipmentEditText, rentPerDayEditText, depositEditText;
    private Button registerButton;
    private DatabaseReference databaseRenters;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_renter_registration_3_1);

        // Initialize Firebase Database reference
        databaseRenters = FirebaseDatabase.getInstance().getReference("renters");

        // Bind UI elements
        renterNameEditText = findViewById(R.id.renterNameEditText);
        renterPhoneEditText = findViewById(R.id.renterPhone);
        renterEmailEditText = findViewById(R.id.renterEmail);
        renterAddressEditText = findViewById(R.id.renterAddress);
        equipmentEditText = findViewById(R.id.equipmentEditText);
        rentPerDayEditText = findViewById(R.id.Rentperday);
        depositEditText = findViewById(R.id.depositEditText);
        registerButton = findViewById(R.id.registerButton);

        // Set click listener on register button
        registerButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                registerRenter();
            }
        });
    }

    private void registerRenter() {
        // Get the input values
        String renterName = renterNameEditText.getText().toString().trim();
        String renterPhone = renterPhoneEditText.getText().toString().trim();
        String renterEmail = renterEmailEditText.getText().toString().trim();
        String renterAddress = renterAddressEditText.getText().toString().trim();
        String equipment = equipmentEditText.getText().toString().trim();
        String rentPerDay = rentPerDayEditText.getText().toString().trim();
        String deposit = depositEditText.getText().toString().trim();

        // Validate input fields
        if (TextUtils.isEmpty(renterName)) {
            renterNameEditText.setError("Renter Name is required.");
            return;
        }

        if (TextUtils.isEmpty(renterPhone)) {
            renterPhoneEditText.setError("Phone number is required.");
            return;
        }

        if (TextUtils.isEmpty(renterEmail)) {
            renterEmailEditText.setError("Email is required.");
            return;
        }

        if (TextUtils.isEmpty(renterAddress)) {
            renterAddressEditText.setError("Address is required.");
            return;
        }

        if (TextUtils.isEmpty(equipment)) {
            equipmentEditText.setError("Equipment is required.");
            return;
        }

        if (TextUtils.isEmpty(rentPerDay)) {
            rentPerDayEditText.setError("Rent per day is required.");
            return;
        }

        if (TextUtils.isEmpty(deposit)) {
            depositEditText.setError("Deposit is required.");
            return;
        }

        // Generate a unique ID for the renter
        String renterId = databaseRenters.push().getKey();

        // Create a Renter object
        Renter renter = new Renter(renterId, renterName, renterPhone, renterEmail, renterAddress, equipment, rentPerDay, deposit);

        // Save the Renter object to the Firebase Database
        if (renterId != null) {
            databaseRenters.child(renterId).setValue(renter).addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if (task.isSuccessful()) {
                        Toast.makeText(RenterRegistrationActivity_3_1.this, "Renter registered successfully!", Toast.LENGTH_SHORT).show();

                        // Clear the input fields after successful registration
                        renterNameEditText.setText("");
                        renterPhoneEditText.setText("");
                        renterEmailEditText.setText("");
                        renterAddressEditText.setText("");
                        equipmentEditText.setText("");
                        rentPerDayEditText.setText("");
                        depositEditText.setText("");

                        // Redirect to FarmerListActivity
                        Intent intent = new Intent(RenterRegistrationActivity_3_1.this, RoleSelectionActivity_3.class);
                        startActivity(intent);
                        finish();  // Close the current activity
                    } else {
                        Toast.makeText(RenterRegistrationActivity_3_1.this, "Registration failed: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }
}
