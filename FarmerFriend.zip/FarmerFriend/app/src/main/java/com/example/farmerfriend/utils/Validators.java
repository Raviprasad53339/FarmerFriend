package com.example.farmerfriend.utils;

import android.text.TextUtils;
import android.util.Patterns;

public class Validators {

    // Validate email format
    public static boolean isValidEmail(String email) {
        return !TextUtils.isEmpty(email) && Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    // Validate phone number format
    public static boolean isValidPhoneNumber(String phoneNumber) {
        return !TextUtils.isEmpty(phoneNumber) && Patterns.PHONE.matcher(phoneNumber).matches();
    }

    // Validate password length
    public static boolean isValidPassword(String password) {
        return !TextUtils.isEmpty(password) && password.length() >= Constants.MIN_PASSWORD_LENGTH;
    }

    // Validate if text is not empty
    public static boolean isNotEmpty(String text) {
        return !TextUtils.isEmpty(text);
    }
}
