package com.example.farmerfriend.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.farmerfriend.R;

public class FarmerIntroductionActivity_4_1 extends AppCompatActivity {

    private TextView skipButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_farmer_introduction_4_1);

        skipButton = findViewById(R.id.btn_skip);
        skipButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FarmerIntroductionActivity_4_1.this, FarmerMainActivity_5.class));
            }
        });

        findViewById(R.id.btn_next).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Logic to proceed to the next introduction page or FarmerMainActivity
                startActivity(new Intent(FarmerIntroductionActivity_4_1.this, FarmerIntroductionActivity_4_2.class));
            }
        });
    }
}
