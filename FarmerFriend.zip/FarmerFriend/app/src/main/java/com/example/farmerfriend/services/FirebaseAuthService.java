package com.example.farmerfriend.services;

import android.app.Activity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.PhoneAuthCredential;
import com.google.firebase.auth.PhoneAuthProvider;

public class FirebaseAuthService {

    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;

    public FirebaseAuthService() {
        mAuth = FirebaseAuth.getInstance();
    }

    // Register with phone number
    public void signInWithPhoneNumber(PhoneAuthCredential credential, final AuthCallback callback) {
        mAuth.signInWithCredential(credential)
                .addOnCompleteListener((Activity) callback, task -> {
                    if (task.isSuccessful()) {
                        callback.onSuccess(mAuth.getCurrentUser());
                    } else {
                        callback.onFailure(task.getException());
                    }
                });
    }

    // Sign in with Google
    public void signInWithGoogle(String idToken, final AuthCallback callback) {
        mAuth.signInWithCredential(PhoneAuthProvider.getCredential(idToken, null))
                .addOnCompleteListener((Activity) callback, task -> {
                    if (task.isSuccessful()) {
                        callback.onSuccess(mAuth.getCurrentUser());
                    } else {
                        callback.onFailure(task.getException());
                    }
                });
    }

    // Sign out
    public void signOut() {
        mAuth.signOut();
    }

    // Get current user
    public FirebaseUser getCurrentUser() {
        return mAuth.getCurrentUser();
    }

    public interface AuthCallback {
        void onSuccess(FirebaseUser user);

        void onFailure(Exception e);
    }
}

