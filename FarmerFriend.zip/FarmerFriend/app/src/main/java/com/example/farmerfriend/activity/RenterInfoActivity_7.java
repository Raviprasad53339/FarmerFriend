package com.example.farmerfriend.activity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ClickableSpan;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.farmerfriend.R;
import com.example.farmerfriend.module.Renter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.razorpay.Checkout;
import com.razorpay.PaymentResultListener;

import org.json.JSONObject;

public class RenterInfoActivity_7 extends AppCompatActivity implements PaymentResultListener {

    private ImageView profileImageView;
    private TextView renterNameTextView, renterPhoneTextView, renterEmailTextView, renterAddressTextView, termsTextView;
    private Button payNowButton;
    private CheckBox termsCheckBox;
    private DatabaseReference rentersRef;
    private String renterId;
    private String renterPhone;
    private int rentAmount; // Amount in INR
    private int depositAmount; // Deposit amount in INR

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_renter_info_7);

        // Initialize views
        profileImageView = findViewById(R.id.profileImageView);
        renterNameTextView = findViewById(R.id.renterNameTextView);
        renterPhoneTextView = findViewById(R.id.renterPhoneTextView);
        renterEmailTextView = findViewById(R.id.renterEmailTextView);
        renterAddressTextView = findViewById(R.id.renterAddressTextView);
        payNowButton = findViewById(R.id.payNowButton);
        termsCheckBox = findViewById(R.id.termsCheckBox);
        termsTextView = findViewById(R.id.termsTextView);

        // Set up clickable "Terms & Conditions"
        SpannableString spannableString = new SpannableString("Terms & Conditions");
        ClickableSpan clickableSpan = new ClickableSpan() {
            @Override
            public void onClick(View widget) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://docs.google.com/document/d/1KOAgIewHOwnMVi_SKTk5f58uxZmdLinS_Zat2kf2MCQ/edit?usp=sharing"));
                startActivity(browserIntent);
            }
        };
        spannableString.setSpan(clickableSpan, 0, spannableString.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        termsTextView.setText(spannableString);
        termsTextView.setMovementMethod(android.text.method.LinkMovementMethod.getInstance());

        // Get the renter ID from the Intent
        Intent intent = getIntent();
        renterId = intent.getStringExtra("renterId");

        if (renterId == null) {
            Toast.makeText(this, "Invalid renter ID.", Toast.LENGTH_SHORT).show();
            finish(); // Close the activity
            return;
        }

        rentersRef = FirebaseDatabase.getInstance().getReference("renters");

        // Fetch renter details from Firebase
        rentersRef.child(renterId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    Renter renter = dataSnapshot.getValue(Renter.class);
                    if (renter != null) {
                        // Update UI with renter details
                        renterNameTextView.setText("Name: " + renter.getRenterName());
                        renterPhoneTextView.setText("Phone: " + renter.getRenterPhone());
                        renterEmailTextView.setText("Email: " + renter.getRenterEmail());
                        renterAddressTextView.setText("Address: " + renter.getRenterAddress());
                        renterPhone = renter.getRenterPhone();
                        rentAmount = Integer.parseInt(renter.getRentPerDay()); // Assuming you have rent amount in your Renter model
                        depositAmount = Integer.parseInt(renter.getDeposit()); // Using getDeposit method

                        // Placeholder for profile image, if available
                        profileImageView.setImageResource(R.drawable.profile); // Replace with actual image loading
                    }
                } else {
                    Toast.makeText(RenterInfoActivity_7.this, "Renter not found.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(RenterInfoActivity_7.this, "Failed to load renter details.", Toast.LENGTH_SHORT).show();
            }
        });

        // Set up Pay Now button click listener
        payNowButton.setOnClickListener(v -> {
            if (termsCheckBox.isChecked()) {
                startPayment();
            } else {
                Toast.makeText(this, "Please accept the Terms and Conditions to proceed.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void startPayment() {
        final Checkout checkout = new Checkout();
        checkout.setKeyID("rzp_test_QGpo9XeJKaoPgM"); // Replace with your Razorpay Key ID

        try {
            JSONObject options = new JSONObject();
            options.put("name", "Farmers Friend App");
            options.put("description", "Payment for equipment deposit");
            options.put("currency", "INR");
            options.put("amount", depositAmount * 100); // Use deposit amount instead of rent amount

            JSONObject preFill = new JSONObject();
            preFill.put("email", "customer@example.com"); // Optional
            preFill.put("contact", renterPhone); // Renter's phone number

            options.put("prefill", preFill);

            checkout.open(this, options);
        } catch (Exception e) {
            Toast.makeText(RenterInfoActivity_7.this, "Error in payment: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }

    @Override
    public void onPaymentSuccess(String paymentId) {
        // Handle payment success
        Toast.makeText(this, "Payment Successful: " + paymentId, Toast.LENGTH_SHORT).show();

        // Redirect to ThankYouFarmerActivity
        Intent intent = new Intent(RenterInfoActivity_7.this, ThankYouFarmerActivity_8.class);
        startActivity(intent);
        finish(); // Optionally finish this activity
    }

    @Override
    public void onPaymentError(int code, String response) {
        // Handle payment failure
        Toast.makeText(this, "Payment Failed: " + response, Toast.LENGTH_SHORT).show();
    }
}
