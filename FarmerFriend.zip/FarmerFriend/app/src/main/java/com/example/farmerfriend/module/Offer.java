package com.example.farmerfriend.module;

import java.io.Serializable;

public class Offer implements Serializable {

    private String id;
    private String farmerId;
    private String equipment;
    private int offerAmount;
    private String offerStatus; // "Pending", "Accepted", "Rejected"

    public Offer() {
        // Default constructor required for calls to DataSnapshot.getValue(Offer.class)
    }

    public Offer(String id, String farmerId, String equipment, int offerAmount, String offerStatus) {
        this.id = id;
        this.farmerId = farmerId;
        this.equipment = equipment;
        this.offerAmount = offerAmount;
        this.offerStatus = offerStatus;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFarmerId() {
        return farmerId;
    }

    public void setFarmerId(String farmerId) {
        this.farmerId = farmerId;
    }

    public String getEquipment() {
        return equipment;
    }

    public void setEquipment(String equipment) {
        this.equipment = equipment;
    }

    public int getOfferAmount() {
        return offerAmount;
    }

    public void setOfferAmount(int offerAmount) {
        this.offerAmount = offerAmount;
    }

    public String getOfferStatus() {
        return offerStatus;
    }

    public void setOfferStatus(String offerStatus) {
        this.offerStatus = offerStatus;
    }
}
