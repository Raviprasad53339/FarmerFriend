package com.example.farmerfriend.services;

import com.example.farmerfriend.module.Offer;
import com.example.farmerfriend.module.Renter;
import com.example.farmerfriend.module.User;
import com.example.farmerfriend.utils.Constants;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FirebaseDatabaseService {

    private DatabaseReference database;

    public FirebaseDatabaseService() {
        database = FirebaseDatabase.getInstance().getReference();
    }

    // Save a user to the database
    public void saveUser(User user) {
        database.child(Constants.USERS).child(user.getId()).setValue(user);
    }

    // Save an offer to the database
    public void saveOffer(Offer offer) {
        database.child(Constants.OFFERS).child(offer.getId()).setValue(offer);
    }

    // Save a renter to the database
    public void saveRenter(Renter renter) {
        database.child(Constants.RENTERS).child(renter.getRenterId()).setValue(renter);
    }

    // Get a reference to a user
    public DatabaseReference getUserReference(String userId) {
        return database.child(Constants.USERS).child(userId);
    }

    // Get a reference to an offer
    public DatabaseReference getOfferReference(String offerId) {
        return database.child(Constants.OFFERS).child(offerId);
    }

    // Get a reference to a renter
    public DatabaseReference getRenterReference(String renterId) {
        return database.child(Constants.RENTERS).child(renterId);
    }
}

