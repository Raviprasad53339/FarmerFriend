package com.example.farmerfriend.activity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.farmerfriend.R;
import com.example.farmerfriend.databinding.ActivityGoogleLogin1Binding;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.util.Locale;

public class GoogleLoginActivity_1 extends AppCompatActivity {

    // UI elements
    private ActivityGoogleLogin1Binding binding;
    private EditText etEmail, etPassword;
    private Button btnLogin;
    private TextView tvRegister, btnLanguage;

    // Firebase Authentication
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Binding for layout
        binding = ActivityGoogleLogin1Binding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Initialize Firebase Auth
        mAuth = FirebaseAuth.getInstance();

        // Bind UI elements
        etEmail = findViewById(R.id.etEmail);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        tvRegister = findViewById(R.id.tvRegister);
        btnLanguage = findViewById(R.id.btnLanguage);

        // Load saved language preferences
        loadLocale();

        // Language selection button click
        btnLanguage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                btnLanguage();
            }
        });

        // Handle login button click
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = etEmail.getText().toString().trim();
                String password = etPassword.getText().toString().trim();

                if (TextUtils.isEmpty(email)) {
                    etEmail.setError("Email is required.");
                    return;
                }

                if (TextUtils.isEmpty(password)) {
                    etPassword.setError("Password is required.");
                    return;
                }

                // Authenticate user
                mAuth.signInWithEmailAndPassword(email, password)
                        .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (task.isSuccessful()) {
                                    // Redirect to RoleSelectionActivity
                                    startActivity(new Intent(GoogleLoginActivity_1.this, RoleSelectionActivity_3.class));
                                    finish();
                                } else {
                                    Toast.makeText(GoogleLoginActivity_1.this, "Login failed: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                                }
                            }
                        });
            }
        });

        // Handle register text click
        tvRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Redirect to EmailRegisterActivity
                startActivity(new Intent(GoogleLoginActivity_1.this, EmailRegisterActivity_2.class));
            }
        });
    }

    // Language selection dialog
    private void btnLanguage() {
        final String[] languages = {"English", "Hindi", "Marathi"};
        AlertDialog.Builder mBuilder = new AlertDialog.Builder(this);
        mBuilder.setTitle("Choose Language");
        mBuilder.setSingleChoiceItems(languages, -1, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == 0) {
                    setLocale("en"); // English
                    recreate();
                } else if (which == 1) {
                    setLocale("hi"); // Hindi
                    recreate();
                } else if (which == 2) {
                    setLocale("mr"); // Marathi
                    recreate();
                }
                dialog.dismiss(); // Close the dialog after selecting a language
            }
        });
        mBuilder.create().show();
    }

    // Set the app's locale
    private void setLocale(String language) {
        Locale locale = new Locale(language);
        Locale.setDefault(locale);

        Configuration configuration = new Configuration();
        configuration.setLocale(locale);
        getBaseContext().getResources().updateConfiguration(configuration, getBaseContext().getResources().getDisplayMetrics());

        SharedPreferences.Editor editor = getSharedPreferences("Settings", MODE_PRIVATE).edit();
        editor.putString("app_Lang", language);
        editor.apply();
    }

    // Load saved language preferences
    private void loadLocale() {
        SharedPreferences preferences = getSharedPreferences("Settings", MODE_PRIVATE);
        String language = preferences.getString("app_Lang", "en"); // Default to English if no language is set
        setLocale(language);
    }
}
