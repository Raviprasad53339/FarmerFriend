package com.example.farmerfriend.utils;

public class Constants {

    // Color Constants
    public static final String BACKGROUND_COLOR = "#072D06";
    public static final String BUTTON_COLOR = "#00FF38";
    public static final String CARD_COLOR = "#408F2C";
    public static final String TEXT_COLOR = "#FFFFFF";

    // Firebase Keys
    public static final String USERS = "users";
    public static final String OFFERS = "offers";
    public static final String RENTERS = "renters";

    // Intent Extras
    public static final String EXTRA_USER_ID = "EXTRA_USER_ID";
    public static final String EXTRA_OFFER_ID = "EXTRA_OFFER_ID";

    // Other Constants
    public static final int MIN_PASSWORD_LENGTH = 6;
}

