package com.example.farmerfriend.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

import com.example.farmerfriend.R;

public class RoleSelectionActivity_3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_role_selection_3);

        findViewById(R.id.btn_farmer).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RoleSelectionActivity_3.this, FarmerRegistrationActivity_4.class));
            }
        });

        findViewById(R.id.btn_renter).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(RoleSelectionActivity_3.this, RenterRegistrationActivity_3_1.class));
            }
        });
    }
}
